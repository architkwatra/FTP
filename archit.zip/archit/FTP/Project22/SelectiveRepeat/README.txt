Steps to run the Project2

1. Ensure that the file to be sent is in the same directory as the client.py file

2. First run the server as 
python server.py #SERVER_PORT #FILE_NAME #P_VALUE #N_VALUE
where #ABC means a command line argument

3. Run the client as
python client.py #SERVER_IP #SERVER_PORT #FILE_NAME #N_VALUE #MSS_VALUE
where #ABC means a command line argument

4. The file will be downloaded in the same directory as server.py